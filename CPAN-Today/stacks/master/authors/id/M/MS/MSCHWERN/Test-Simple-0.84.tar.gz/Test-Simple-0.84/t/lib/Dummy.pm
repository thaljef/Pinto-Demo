package Dummy;
# $Id: /mirror/googlecode/test-more/t/lib/Dummy.pm 57943 2008-08-18T02:09:22.275428Z brooklyn.kid51  $

$VERSION = '0.01';

1;
