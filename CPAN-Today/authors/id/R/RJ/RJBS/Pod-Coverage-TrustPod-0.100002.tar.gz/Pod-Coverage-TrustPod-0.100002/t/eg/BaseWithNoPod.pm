package BaseWithNoPod;

use strict;
use warnings;


1;
