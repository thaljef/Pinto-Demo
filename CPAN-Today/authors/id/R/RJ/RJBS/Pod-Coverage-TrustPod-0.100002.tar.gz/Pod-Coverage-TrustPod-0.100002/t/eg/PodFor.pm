
use strict;
use warnings;

package PodFor;

=head1 NAME

PodFor - there are privacy instructions in POD =for

=for Pod::Coverage not_covered p...s

=cut

sub not_covered { }

sub pants { }

1;
