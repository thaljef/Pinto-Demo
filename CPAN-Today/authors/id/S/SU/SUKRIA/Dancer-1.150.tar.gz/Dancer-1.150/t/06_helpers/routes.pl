get '/foo' => sub { 'foo loaded' };

